##
## Black-capped chickadees sequences
##
## Anonymous nuclear loci from Black-capped chickadees (Poecile atricapillus).
## Data used in Harris et al. 2013.
##
## @aliases apex.datasets
## @rdname apex.datasets
## @docType data
##
## @author Rebecca Harris <rbharris@@uw.edu>
##
##
NULL
