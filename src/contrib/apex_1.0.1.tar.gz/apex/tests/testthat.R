library(testthat)
library(apex)

test_check("apex")
