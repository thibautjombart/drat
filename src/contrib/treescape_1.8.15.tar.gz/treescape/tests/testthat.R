library(testthat)
library(treescape)

test_check("treescape")
