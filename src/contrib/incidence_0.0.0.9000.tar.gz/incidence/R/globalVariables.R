## hack to get rid of warnings
if(getRversion() >= "2.15.1")  utils::globalVariables(c("y","Incidence","mydate","freq"))
