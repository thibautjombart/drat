if (require("testthat") && packageVersion("testthat") >= "0.8") {
    test_check("incidence")
}
