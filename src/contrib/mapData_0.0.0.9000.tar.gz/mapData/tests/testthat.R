library(testthat)
library(mapData)

test_check("mapData")
