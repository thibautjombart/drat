[![Build Status](https://travis-ci.org/Hackout2/incidence.svg?branch=master)](https://travis-ci.org/Hackout2/incidence)

# incidence
The incidence package for computation and visualization of incidence from outbreak linelists

Description:
------------
To see an overview of package functionality check the package
[wiki](https://github.com/Hackout2/incidence/wiki).

